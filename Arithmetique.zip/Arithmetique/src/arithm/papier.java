package arithm;

public class papier {
	
	private int agee,agep;
	
	public papier ()
	{
		agee=0;
		agep=0;
	}

	public int getAgee() {
		return agee;
	}

	public void setAgee(int agee) {
		this.agee = agee;
	}

	public int getAgep() {
		return agep;
	}

	public void setAgep(int agep) {
		this.agep = agep;
	}

}
